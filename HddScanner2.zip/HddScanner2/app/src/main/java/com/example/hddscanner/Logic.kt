package com.example.hddscanner

import java.util.Locale

/** منطق خالص (بدون وابستگی به اندروید) — کاملاً قابل تست واحد */

object Sim {
    private val groups = listOf("0OQ", "1IL", "5S", "8B", "2Z", "6G")

    fun norm(s: String): String = s.uppercase(Locale.ROOT).filter { it.isLetterOrDigit() }

    /** شکل کانونی: حروف شبیه هم به یک کاراکتر نگاشت می‌شوند (برای گروه‌بندی و تکراری‌یاب) */
    fun canon(s: String): String = norm(s).map { c ->
        when (c) {
            'O', 'Q' -> '0'
            'I', 'L' -> '1'
            'S' -> '5'
            'B' -> '8'
            'Z' -> '2'
            'G' -> '6'
            else -> c
        }
    }.joinToString("")

    private fun subCost(a: Char, b: Char): Double = when {
        a == b -> 0.0
        groups.any { a in it && b in it } -> 0.25
        else -> 1.0
    }

    fun wdist(a: String, b: String): Double {
        val n = a.length
        val m = b.length
        var prev = DoubleArray(m + 1) { it.toDouble() }
        for (i in 1..n) {
            val cur = DoubleArray(m + 1)
            cur[0] = i.toDouble()
            for (j in 1..m) {
                val sub = prev[j - 1] + subCost(a[i - 1], b[j - 1])
                val del = prev[j] + 1.0
                val ins = cur[j - 1] + 1.0
                cur[j] = minOf(sub, del, ins)
            }
            prev = cur
        }
        return prev[m]
    }

    data class Score(val similarity: Double, val cost: Double, val sameLength: Boolean)

    /** شباهت دو رشته؛ حداکثر ۲ کاراکتر اضافه در ابتدا/انتهای رشته بلندتر با هزینه ۰٫۵ نادیده گرفته می‌شود */
    fun score(x: String, y: String): Score {
        val a = norm(x)
        val b = norm(y)
        if (a.isEmpty() || b.isEmpty()) return Score(0.0, 99.0, false)
        val longer = if (a.length >= b.length) a else b
        val shorter = if (a.length >= b.length) b else a
        var best = Double.MAX_VALUE
        for (p in 0..2) {
            for (s in 0..(2 - p)) {
                if (p + s > longer.length - 1) continue
                val t = longer.substring(p, longer.length - s)
                val c = 0.5 * (p + s) + wdist(t, shorter)
                if (c < best) best = c
            }
        }
        val sim = maxOf(0.0, 1.0 - best / longer.length.toDouble())
        return Score(sim, best, a.length == b.length)
    }

    /** قانون سخت‌گیرانه سبز: شباهت ≥ ۸۵٪، حداکثر یک خطای واقعی (برای سریال کوتاه ۰٫۵) و طول برابر */
    fun isStrong(sc: Score, len: Int): Boolean =
        sc.similarity >= 0.85 && sc.cost <= (if (len < 7) 0.5 else 1.0) && sc.sameLength

    /** متن یک بارکد را به نامزدهای سریال می‌شکند (برای QR/DataMatrix چندفیلدی مثل SN:xxx;PN:yyy) */
    fun tokens(code: String): List<String> {
        val out = linkedSetOf<String>()
        val whole = code.trim()
        if (whole.isNotEmpty()) out.add(whole)
        for (part in whole.split(Regex("""[;,|\s\u001D]+"""))) {
            if (part.isEmpty()) continue
            val a = part.substringAfter(':', part)
            val v = a.substringAfter('=', a)
            out.add(v)
        }
        return out.filter { norm(it).length in 6..24 }
    }
}

/** قالب سریال برندها — تقریبی و هنوز با لیبل واقعی راستی‌آزمایی نشده؛ فقط برای نارنجی/قرمز استفاده می‌شود، نه برای تأیید */
object SerialRules {
    private val generic = Regex("^[A-Z0-9]{8,20}$")
    private val wd = Regex("^W[A-Z0-9]{9,13}$")
    private val seagate = Regex("^[A-Z0-9]{8,9}$")
    private val samsung = Regex("^S[A-Z0-9]{12,15}$")

    fun valid(brand: String?, serial: String): Boolean {
        val s = Sim.norm(serial)
        if (!generic.matches(s) || s.none { it.isDigit() }) return false
        return when (brand) {
            "Western Digital" -> wd.matches(s)
            "Seagate" -> seagate.matches(s)
            "Samsung" -> samsung.matches(s)
            else -> true
        }
    }
}

enum class Level { PENDING, GREEN, YELLOW, ORANGE, RED, BLUE }

data class Verdict(
    val level: Level = Level.PENDING,
    val serial: String = "",
    val similarity: Double = 0.0,
    val source: String = "",        // BARCODE+OCR | OCR | BARCODE
    val reason: String = "",
    val confirmed: Boolean = false  // پایه سبز بوده (حتی اگر بعداً آبی/تکراری شده)
)

class SerialDecider(private val isDuplicate: (String) -> Boolean = { false }) {

    private val variants = HashMap<String, HashMap<String, Int>>()   // canon -> (variant -> count)
    private val ocrRaw = HashMap<String, String>()
    private val seen = LinkedHashMap<String, Int>()                  // token -> تعداد فریم پشت‌سرهم/نزدیک
    private val seenAt = HashMap<String, Long>()                     // آخرین زمان دیده‌شدن
    private val rawOf = HashMap<String, String>()
    private val support = HashMap<String, MutableList<Long>>()
    private val modelNorms = HashSet<String>()
    private var modelSeen = false
    private var lastModel: String? = null
    private var lockedModel: String? = null
    private var brand: String? = null
    private var firstAt = -1L
    private var streak = 0
    private var diverge = 0

    var locked: Verdict? = null
        private set
    var newDriveDetected = false
        private set
    var frames = 0
        private set

    private companion object {
        const val CAND = 0.80
        const val MARGIN = 0.10
        const val WINDOW = 3000L
        const val TIMEOUT = 10_000L
        const val TOKEN_TTL = 5000L
        const val MAX_CODES = 6
    }

    private fun clearEvidence() {
        variants.clear(); ocrRaw.clear(); seen.clear(); seenAt.clear(); rawOf.clear(); support.clear()
        modelNorms.clear(); modelSeen = false; lastModel = null; brand = null
        firstAt = -1L
    }

    fun reset() {
        clearEvidence()
        streak = 0; diverge = 0
        locked = null; lockedModel = null; newDriveDetected = false; frames = 0
    }

    private fun noteMeta(ocr: LabelParser.Ocr) {
        ocr.model?.let { modelSeen = true; lastModel = Sim.norm(it); modelNorms.add(Sim.norm(it)) }
        ocr.pn?.let { modelNorms.add(Sim.norm(it)) }
        if (ocr.brand != null) brand = ocr.brand
    }

    private fun tokensOf(barcodes: List<String>): List<String> {
        val out = ArrayList<String>()
        for (r in barcodes.flatMap { Sim.tokens(it) }) {
            if (LabelParser.looksLikeModel(r)) continue
            val n = Sim.norm(r)
            if (n in modelNorms || n in out) continue
            out.add(n)
            rawOf.getOrPut(n) { r.uppercase(Locale.ROOT).trim() }
        }
        return out
    }

    private fun topVariant(): String? {
        val g = variants.values.maxByOrNull { it.values.sum() } ?: return null
        return g.maxByOrNull { it.value }?.key
    }

    fun onFrame(now: Long, ocr: LabelParser.Ocr, barcodes: List<String>): Verdict {
        frames++
        val ocrSerial = ocr.serial?.let { Sim.norm(it) }?.takeIf { it.isNotEmpty() }

        // --- بعد از قفل: فقط تشخیص هارد جدید (با بارکد، سریال OCR یا مدل متفاوت) ---
        val lk = locked
        if (lk != null) {
            val lkNorm = Sim.norm(lk.serial)
            val serialLike = tokensOf(barcodes).filter { SerialRules.valid(null, it) }
            val bForeign = serialLike.any { Sim.score(lkNorm, it).similarity < 0.5 }
            val bSame = serialLike.any { Sim.score(lkNorm, it).similarity >= CAND }
            val oSim = ocrSerial?.let { Sim.score(lkNorm, it).similarity }
            val oForeign = oSim != null && oSim < 0.5
            val oSame = oSim != null && oSim >= CAND
            val lm = lockedModel
            val om = ocr.model
            val mForeign = lm != null && om != null && Sim.score(lm, om).similarity < 0.5
            val foreign = bForeign || oForeign || mForeign
            val same = bSame || oSame
            streak = if (foreign && !same) streak + 1 else 0
            if (streak >= 3) newDriveDetected = true
            return lk
        }

        if (ocr.multi) {
            return Verdict(Level.RED, reason = "چند لیبل یا چند سریال در تصویر است؛ فقط یک لیبل را قاب بگیر")
        }
        noteMeta(ocr)

        // --- جدا شدن شواهد: سریال OCR کاملاً متفاوت با سریال غالب = هارد عوض شده ---
        if (ocrSerial != null) {
            val cur = topVariant()
            if (cur != null && Sim.score(cur, ocrSerial).similarity < 0.5) {
                diverge++
                if (diverge >= 2) {
                    clearEvidence(); diverge = 0
                    noteMeta(ocr)
                }
            } else {
                diverge = 0
            }
        }

        val tokens = tokensOf(barcodes)
        val distinctCodes = barcodes.map { Sim.norm(it) }.filter { it.isNotEmpty() }.distinct()
        if (distinctCodes.size > MAX_CODES) {
            return Verdict(Level.RED, reason = "چند هارد در تصویر است؛ فقط یک هارد را قاب بگیر")
        }

        if (ocrSerial != null || tokens.isNotEmpty()) {
            if (firstAt < 0) firstAt = now
        }
        if (ocrSerial != null) {
            ocrRaw.getOrPut(ocrSerial) { ocr.serial!!.trim().uppercase(Locale.ROOT) }
            val g = variants.getOrPut(Sim.canon(ocrSerial)) { HashMap() }
            g[ocrSerial] = (g[ocrSerial] ?: 0) + 1
        }
        for (t in tokens) {
            val last = seenAt[t]
            seen[t] = if (last != null && now - last <= TOKEN_TTL) (seen[t] ?: 0) + 1 else 1
            seenAt[t] = now
            if (ocrSerial != null && Sim.score(ocrSerial, t).similarity >= CAND) {
                support.getOrPut(t) { ArrayList() }.add(now)
            }
        }

        val v = decide(now)
        if (v.confirmed) {
            locked = v
            lockedModel = lastModel
            streak = 0
        }
        return v
    }

    private fun decide(now: Long): Verdict {
        val elapsed = if (firstAt < 0) 0L else now - firstAt
        val topGroup = variants.values.maxByOrNull { g -> g.values.sum() }
        val top: String? = topGroup?.maxByOrNull { it.value }?.key
        val topCount = topGroup?.values?.sum() ?: 0
        // بارکدهایی که بیش از ۵ ثانیه دیده نشده‌اند (مربوط به هارد قبلی) نادیده گرفته می‌شوند
        val cands = seen.keys.filter { it !in modelNorms && now - (seenAt[it] ?: -1_000_000L) <= TOKEN_TTL }
        val base = if (top != null) withOcr(now, elapsed, top, topCount, cands) else noOcr(elapsed, cands)
        return markDuplicate(base)
    }

    private fun withOcr(now: Long, elapsed: Long, top: String, topCount: Int, cands: List<String>): Verdict {
        val scored = cands.map { it to Sim.score(top, it) }.sortedByDescending { it.second.similarity }
        val best = scored.firstOrNull()
        if (best != null && best.second.similarity >= CAND) {
            val second = scored.getOrNull(1)
            if (second != null && second.second.similarity >= CAND &&
                best.second.similarity - second.second.similarity < MARGIN
            ) {
                return Verdict(Level.RED, reason = "چند بارکد شبیه هم است؛ سریال مبهم — نزدیک‌تر بگیر")
            }
            val token = best.first
            val sc = best.second
            val serial = rawOf[token] ?: token
            val recent = support[token]?.count { now - it <= WINDOW } ?: 0
            val strong = Sim.isStrong(sc, top.length)
            val pct = (sc.similarity * 100).toInt()
            return when {
                strong && recent >= 2 && modelSeen ->
                    Verdict(Level.GREEN, serial, sc.similarity, "BARCODE+OCR", "OCR و بارکد همخوان‌اند", confirmed = true)
                strong && recent >= 2 ->
                    Verdict(Level.YELLOW, serial, sc.similarity, "BARCODE+OCR", "سریال تأیید شد ولی مدل خوانده نشد")
                strong && elapsed <= TIMEOUT ->
                    Verdict(Level.PENDING, serial, sc.similarity, "BARCODE+OCR", "در حال تأیید…")
                strong ->
                    Verdict(Level.YELLOW, serial, sc.similarity, "BARCODE+OCR", "فقط یک فریم تأیید دارد؛ بررسی دستی")
                else ->
                    Verdict(Level.YELLOW, serial, sc.similarity, "BARCODE+OCR", "شباهت $pct٪ یا طول متفاوت؛ بررسی دستی")
            }
        }
        return when {
            topCount >= 4 && elapsed >= 3000 ->
                Verdict(Level.YELLOW, ocrRaw[top] ?: top, 0.0, "OCR", "فقط OCR خوانده شد؛ بارکد همخوان پیدا نشد — تأیید دستی")
            elapsed > TIMEOUT ->
                Verdict(Level.RED, reason = "سریال ناپایدار است؛ دوربین را ثابت نگه دار")
            else -> Verdict()
        }
    }

    private fun noOcr(elapsed: Long, cands: List<String>): Verdict {
        val valid = cands.filter { SerialRules.valid(brand, it) }
        if (valid.size == 1 && (seen[valid[0]] ?: 0) >= 3 && elapsed >= 3000) {
            return Verdict(
                Level.ORANGE, rawOf[valid[0]] ?: valid[0], 0.0, "BARCODE",
                "فقط بارکد خوانده شد؛ S/N با OCR پیدا نشد — تأیید دستی"
            )
        }
        if (elapsed > TIMEOUT) {
            val reason = when {
                valid.size > 1 -> "چند بارکد دیده شد؛ سریال مشخص نیست — S/N را نزدیک‌تر بگیر"
                cands.isNotEmpty() -> "S/N با OCR خوانده نشد؛ نزدیک‌تر بگیر"
                else -> "سریال خوانده نشد؛ نور، فاصله یا زاویه را تغییر بده"
            }
            return Verdict(Level.RED, reason = reason)
        }
        return Verdict()
    }

    private fun markDuplicate(v: Verdict): Verdict {
        val eligible = v.level == Level.GREEN || v.level == Level.YELLOW || v.level == Level.ORANGE
        if (eligible && v.serial.isNotBlank() && isDuplicate(v.serial)) {
            return v.copy(level = Level.BLUE, reason = "این سریال قبلاً ثبت شده است")
        }
        return v
    }
}
