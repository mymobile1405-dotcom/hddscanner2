package com.example.hddscanner

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScanViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()

    val entries: StateFlow<List<HddEntry>> =
        dao.all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private fun isDup(serial: String, excludeId: Long = 0): Boolean {
        val c = Sim.canon(serial)
        return c.isNotEmpty() && entries.value.any { it.id != excludeId && Sim.canon(it.serial) == c }
    }

    private val decider = SerialDecider { s -> isDup(s) }

    // رأی‌گیری فیلدهای غیرسریال (برند، مدل، ظرفیت، ...)
    private val votes = HashMap<String, HashMap<String, Int>>()
    private val edited = HashSet<String>()            // فیلدهایی که کاربر دستی ویرایش کرده
    private val _fields = MutableStateFlow<Map<String, String>>(emptyMap())
    val fields: StateFlow<Map<String, String>> = _fields
    private val _verdict = MutableStateFlow(Verdict())
    val verdict: StateFlow<Verdict> = _verdict
    private val _frames = MutableStateFlow(0)
    val frames: StateFlow<Int> = _frames
    private val _raw = MutableStateFlow("")
    val raw: StateFlow<String> = _raw
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    /** فریم زنده دوربین */
    fun onFrame(text: String, codes: List<String>) {
        process(text, codes, 1, listOf(SystemClock.elapsedRealtime()))
    }

    /** عکس ثابت (گالری): معادل چند فریم پشت‌سرهم است */
    fun onPhoto(text: String, codes: List<String>) {
        val base = SystemClock.elapsedRealtime()
        process(text, codes, 3, (0..4).map { base + it * 1000L })
    }

    private fun process(text: String, codes: List<String>, weight: Int, times: List<Long>) {
        _raw.value = "TEXT:\n$text\n\nBARCODES: ${codes.joinToString(" | ")}"
        val o = LabelParser.ocr(text)
        var v = _verdict.value
        for (t in times) v = decider.onFrame(t, o, codes)

        if (decider.newDriveDetected) {
            reset()
            _message.value = "هارد جدید دیده شد؛ نتیجه ثبت‌نشده قبلی کنار گذاشته شد"
            return
        }
        _verdict.value = v
        _frames.value = decider.frames

        mapOf(
            F.BRAND to o.brand, F.MODEL to o.model, F.TYPE to o.type,
            F.PN to o.pn, F.CAPACITY to o.capacity, F.MFG to o.mfg
        ).forEach { (k, value) ->
            if (value != null) {
                val m = votes.getOrPut(k) { HashMap() }
                m[value] = (m[value] ?: 0) + weight
            }
        }
        val cur = _fields.value.toMutableMap()
        votes.forEach { (k, m) ->
            if (k !in edited) m.maxByOrNull { it.value }?.key?.let { cur[k] = it }
        }
        val usable = v.serial.isNotBlank() && v.level != Level.PENDING && v.level != Level.RED
        if (usable && F.SERIAL !in edited) cur[F.SERIAL] = v.serial
        _fields.value = cur
    }

    fun edit(key: String, value: String) {
        edited += key
        _fields.value = _fields.value + (key to value)
    }

    fun reset() {
        votes.clear(); edited.clear(); decider.reset()
        _fields.value = emptyMap(); _verdict.value = Verdict(); _frames.value = 0
    }

    fun save() {
        val f = _fields.value
        if (f[F.MODEL].isNullOrBlank() && f[F.SERIAL].isNullOrBlank()) {
            _message.value = "مدل یا سریال خوانده نشده است"; return
        }
        val serial = f[F.SERIAL].orEmpty().trim()
        if (serial.isNotEmpty() && isDup(serial)) {
            _message.value = "این سریال قبلاً ثبت شده است"; return
        }
        val v = _verdict.value
        val manual = F.SERIAL in edited
        val entry = HddEntry(
            brand = f[F.BRAND].orEmpty().trim(), model = f[F.MODEL].orEmpty().trim(),
            type = f[F.TYPE].orEmpty().trim(), serial = serial,
            partNumber = f[F.PN].orEmpty().trim(), capacity = f[F.CAPACITY].orEmpty().trim(),
            mfgDate = f[F.MFG].orEmpty().trim(), note = f[F.NOTE].orEmpty().trim(),
            status = if (manual) "MANUAL" else v.level.name,
            similarity = if (manual) 0.0 else v.similarity,
            source = if (manual) "MANUAL" else v.source,
            raw = _raw.value.take(2000)
        )
        viewModelScope.launch {
            dao.insert(entry)
            reset()
            _message.value = "ثبت شد ✓"
        }
    }

    fun update(e: HddEntry) {
        if (e.serial.isNotBlank() && isDup(e.serial, e.id)) {
            _message.value = "این سریال برای مورد دیگری ثبت شده است"; return
        }
        viewModelScope.launch { dao.update(e) }
    }

    fun delete(e: HddEntry) { viewModelScope.launch { dao.delete(e) } }
    fun clearMessage() { _message.value = null }

    fun exportCsv(ctx: Context) {
        viewModelScope.launch {
            val file = withContext(Dispatchers.IO) {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                val f = File(ctx.cacheDir, "hdd_list_$stamp.csv")
                fun cell(s: String): String {
                    val safe = if (s.isNotEmpty() && s[0] in "=+@") "'$s" else s   // جلوگیری از اجرای فرمول در Excel
                    return "\"" + safe.replace("\"", "\"\"") + "\""
                }
                val sb = StringBuilder("\uFEFF")   // BOM برای Excel
                sb.append("Brand,Model,Type,Serial,PartNumber,Capacity,MfgDate,Status,Similarity,Source,Note\n")
                dao.snapshot().forEach {
                    sb.append(
                        listOf(
                            it.brand, it.model, it.type, it.serial, it.partNumber, it.capacity, it.mfgDate,
                            it.status, "%.0f".format(Locale.US, it.similarity * 100), it.source, it.note
                        ).joinToString(",") { v -> cell(v) }
                    ).append('\n')
                }
                f.writeText(sb.toString(), Charsets.UTF_8); f
            }
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ctx.startActivity(Intent.createChooser(intent, "اشتراک‌گذاری جدول").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
