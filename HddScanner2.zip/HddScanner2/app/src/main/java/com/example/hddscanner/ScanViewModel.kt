package com.example.hddscanner

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScanViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    private val feedback = Feedback(app)

    val entries: StateFlow<List<HddEntry>> =
        dao.all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // سریال‌هایی که همین الان ذخیره شده‌اند (قبل از رسیدن لیست دیتابیس) — جلوگیری از ذخیره دوباره
    private val savedCanon = HashSet<String>()

    private fun isDup(serial: String, excludeId: Long = 0): Boolean {
        val c = Sim.canon(serial)
        if (c.isEmpty()) return false
        if (excludeId == 0L && c in savedCanon) return true
        return entries.value.any { it.id != excludeId && Sim.canon(it.serial) == c }
    }

    private val decider = SerialDecider { s -> isDup(s) }

    private val votes = HashMap<String, HashMap<String, Int>>()
    private val edited = HashSet<String>()            // فیلدهایی که کاربر دستی ویرایش کرده
    private var frozen = false                        // بعد از سبز/قفل، فیلدها دیگر از فریم‌ها تغییر نمی‌کنند
    private var saving = false
    private var pauseUntil = 0L                       // بعد از ذخیره چند ثانیه فریم‌ها نادیده گرفته می‌شوند
    private var lastLevel = Level.PENDING

    private val _fields = MutableStateFlow<Map<String, String>>(emptyMap())
    val fields: StateFlow<Map<String, String>> = _fields
    private val _verdict = MutableStateFlow(Verdict())
    val verdict: StateFlow<Verdict> = _verdict
    private val _frames = MutableStateFlow(0)
    val frames: StateFlow<Int> = _frames
    private val _raw = MutableStateFlow("")
    val raw: StateFlow<String> = _raw
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message
    private val _mode = MutableStateFlow(feedback.mode)
    val mode: StateFlow<Feedback.Mode> = _mode
    private val _vibrate = MutableStateFlow(feedback.vibrate)
    val vibrate: StateFlow<Boolean> = _vibrate

    fun setMode(m: Feedback.Mode) { feedback.mode = m; _mode.value = m }
    fun setVibrate(on: Boolean) { feedback.vibrate = on; _vibrate.value = on }

    override fun onCleared() {
        feedback.release()
        super.onCleared()
    }

    /** فریم زنده دوربین */
    fun onFrame(text: String, codes: List<String>) {
        process(text, codes, 1, listOf(SystemClock.elapsedRealtime()))
    }

    /** عکس ثابت (گالری): معادل چند فریم پشت‌سرهم است */
    fun onPhoto(text: String, codes: List<String>) {
        val base = SystemClock.elapsedRealtime()
        process(text, codes, 3, (0..4).map { base + it * 1000L })
    }

    private fun process(text: String, codes: List<String>, weight: Int, times: List<Long>) {
        if (SystemClock.elapsedRealtime() < pauseUntil) return
        _raw.value = "TEXT:\n$text\n\nBARCODES: ${codes.joinToString(" | ")}"
        val o = LabelParser.ocr(text)
        var v = _verdict.value
        for (t in times) v = decider.onFrame(t, o, codes)

        if (decider.newDriveDetected) {
            clearSession()
            _message.value = "هارد جدید دیده شد؛ نتیجه ثبت‌نشده قبلی کنار گذاشته شد"
            feedback.play(Level.YELLOW)
            return
        }
        if (v.level != lastLevel) {
            lastLevel = v.level
            feedback.play(v.level)
        }
        _verdict.value = v
        _frames.value = decider.frames
        if (frozen) return

        mapOf(
            F.BRAND to o.brand, F.MODEL to o.model, F.TYPE to o.type,
            F.PN to o.pn, F.CAPACITY to o.capacity, F.MFG to o.mfg
        ).forEach { (k, value) ->
            if (value != null && !o.multi) {
                val m = votes.getOrPut(k) { HashMap() }
                m[value] = (m[value] ?: 0) + weight
            }
        }
        val cur = _fields.value.toMutableMap()
        votes.forEach { (k, m) ->
            if (k !in edited) m.maxByOrNull { it.value }?.key?.let { cur[k] = it }
        }
        val usable = v.serial.isNotBlank() && v.level != Level.PENDING && v.level != Level.RED
        if (usable && F.SERIAL !in edited) cur[F.SERIAL] = v.serial
        _fields.value = cur
        if (decider.locked != null) frozen = true
    }

    fun edit(key: String, value: String) {
        edited += key
        _fields.value = _fields.value + (key to value)
    }

    private fun clearSession() {
        votes.clear(); edited.clear(); decider.reset()
        frozen = false; lastLevel = Level.PENDING
        _fields.value = emptyMap(); _verdict.value = Verdict(); _frames.value = 0
    }

    /** دکمه «پاک کردن / اسکن بعدی» */
    fun reset() {
        pauseUntil = 0L
        clearSession()
    }

    fun save() {
        if (saving) return
        val f = _fields.value
        val serial = f[F.SERIAL].orEmpty().trim()
        if (serial.isEmpty()) {
            _message.value = "سریال خالی است؛ بخوان یا دستی بنویس"; return
        }
        if (isDup(serial)) {
            _message.value = "این سریال قبلاً ثبت شده است"
            feedback.play(Level.BLUE, force = true)
            return
        }
        val v = _verdict.value
        val manual = F.SERIAL in edited
        val entry = HddEntry(
            brand = f[F.BRAND].orEmpty().trim(), model = f[F.MODEL].orEmpty().trim(),
            type = f[F.TYPE].orEmpty().trim(), serial = serial,
            partNumber = f[F.PN].orEmpty().trim(), capacity = f[F.CAPACITY].orEmpty().trim(),
            mfgDate = f[F.MFG].orEmpty().trim(), note = f[F.NOTE].orEmpty().trim(),
            status = if (manual) "MANUAL" else v.level.name,
            similarity = if (manual) 0.0 else v.similarity,
            source = if (manual) "MANUAL" else v.source,
            raw = _raw.value.take(2000)
        )
        val key = Sim.canon(serial)
        saving = true
        savedCanon.add(key)
        pauseUntil = SystemClock.elapsedRealtime() + 2500   // دوربین هنوز روی همین هارد است
        viewModelScope.launch {
            try {
                dao.insert(entry)
                clearSession()
                _message.value = "ثبت شد ✓ — هارد بعدی را بگیر"
                feedback.play(Level.GREEN, force = true)
            } catch (e: Exception) {
                savedCanon.remove(key)
                pauseUntil = 0L
                _message.value = "ذخیره ناموفق بود؛ دوباره امتحان کن"
                feedback.play(Level.RED, force = true)
            } finally {
                saving = false
            }
        }
    }

    fun update(e: HddEntry) {
        if (e.serial.isNotBlank() && isDup(e.serial, e.id)) {
            _message.value = "این سریال برای مورد دیگری ثبت شده است"; return
        }
        viewModelScope.launch { dao.update(e) }
    }

    fun delete(e: HddEntry) {
        savedCanon.remove(Sim.canon(e.serial))
        viewModelScope.launch { dao.delete(e) }
    }

    fun clearMessage() { _message.value = null }

    fun exportCsv(ctx: Context) {
        viewModelScope.launch {
            val file = withContext(Dispatchers.IO) {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                val f = File(ctx.cacheDir, "hdd_list_$stamp.csv")
                fun cell(s: String): String {
                    val safe = if (s.isNotEmpty() && s[0] in "=+@") "'$s" else s   // جلوگیری از اجرای فرمول در Excel
                    return "\"" + safe.replace("\"", "\"\"") + "\""
                }
                val sb = StringBuilder("\uFEFF")   // BOM برای Excel
                sb.append("Brand,Model,Type,Serial,PartNumber,Capacity,MfgDate,Status,Similarity,Source,Note\n")
                dao.snapshot().forEach {
                    sb.append(
                        listOf(
                            it.brand, it.model, it.type, it.serial, it.partNumber, it.capacity, it.mfgDate,
                            it.status, "%.0f".format(Locale.US, it.similarity * 100), it.source, it.note
                        ).joinToString(",") { v -> cell(v) }
                    ).append('\n')
                }
                f.writeText(sb.toString(), Charsets.UTF_8); f
            }
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ctx.startActivity(Intent.createChooser(intent, "اشتراک‌گذاری جدول").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
