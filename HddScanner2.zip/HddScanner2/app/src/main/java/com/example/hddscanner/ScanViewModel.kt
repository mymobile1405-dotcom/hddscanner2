package com.example.hddscanner

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScanViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()

    val entries: StateFlow<List<HddEntry>> =
        dao.all().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // رأی‌گیری بین فریم‌ها
    private val votes = HashMap<String, HashMap<String, Int>>()
    private val locked = HashSet<String>()            // فیلدهایی که کاربر دستی ویرایش کرده
    private val _fields = MutableStateFlow<Map<String, String>>(emptyMap())
    val fields: StateFlow<Map<String, String>> = _fields
    private val _frames = MutableStateFlow(0)
    val frames: StateFlow<Int> = _frames
    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready
    private val _raw = MutableStateFlow("")
    val raw: StateFlow<String> = _raw
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    private fun top(k: String) = votes[k]?.values?.maxOrNull() ?: 0

    fun onFrame(text: String, codes: List<String>, weight: Int = 1) {
        _raw.value = "TEXT:\n$text\n\nBARCODES: ${codes.joinToString(" | ")}"
        val parsed = LabelParser.parse(text, codes)
        if (parsed.isEmpty()) return
        parsed.forEach { (k, v) ->
            val m = votes.getOrPut(k) { HashMap() }
            m[v] = (m[v] ?: 0) + weight
        }
        _frames.value = _frames.value + 1
        val cur = _fields.value.toMutableMap()
        votes.forEach { (k, m) ->
            if (k !in locked) m.maxByOrNull { it.value }?.key?.let { cur[k] = it }
        }
        _fields.value = cur
        _ready.value = top(F.MODEL) >= 3 && top(F.SERIAL) >= 3
    }

    fun edit(key: String, value: String) {
        locked += key
        _fields.value = _fields.value + (key to value)
    }

    fun reset() {
        votes.clear(); locked.clear()
        _fields.value = emptyMap(); _frames.value = 0; _ready.value = false
    }

    fun save() {
        val f = _fields.value
        if (f[F.MODEL].isNullOrBlank() && f[F.SERIAL].isNullOrBlank()) {
            _message.value = "مدل یا سریال خوانده نشده است"; return
        }
        viewModelScope.launch {
            val serial = f[F.SERIAL].orEmpty().trim()
            if (serial.isNotEmpty() && dao.countSerial(serial, 0) > 0) {
                _message.value = "این سریال قبلاً ثبت شده است"; return@launch
            }
            dao.insert(
                HddEntry(
                    brand = f[F.BRAND].orEmpty().trim(), model = f[F.MODEL].orEmpty().trim(),
                    type = f[F.TYPE].orEmpty().trim(), serial = serial,
                    partNumber = f[F.PN].orEmpty().trim(), capacity = f[F.CAPACITY].orEmpty().trim(),
                    mfgDate = f[F.MFG].orEmpty().trim(), note = f[F.NOTE].orEmpty().trim()
                )
            )
            reset()
            _message.value = "ثبت شد ✓"
        }
    }

    fun update(e: HddEntry) {
        viewModelScope.launch {
            if (e.serial.isNotBlank() && dao.countSerial(e.serial, e.id) > 0) {
                _message.value = "این سریال برای مورد دیگری ثبت شده است"; return@launch
            }
            dao.update(e)
        }
    }

    fun delete(e: HddEntry) { viewModelScope.launch { dao.delete(e) } }
    fun clearMessage() { _message.value = null }

    fun exportCsv(ctx: Context) {
        viewModelScope.launch {
            val file = withContext(Dispatchers.IO) {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                val f = File(ctx.cacheDir, "hdd_list_$stamp.csv")
                fun cell(s: String): String {
                    val safe = if (s.isNotEmpty() && s[0] in "=+@") "'$s" else s   // جلوگیری از اجرای فرمول در Excel
                    return "\"" + safe.replace("\"", "\"\"") + "\""
                }
                val sb = StringBuilder("\uFEFF")   // BOM تا Excel فارسی/UTF-8 را درست بخواند
                sb.append("Brand,Model,Type,Serial,PartNumber,Capacity,MfgDate,Note\n")
                dao.snapshot().forEach {
                    sb.append(
                        listOf(it.brand, it.model, it.type, it.serial, it.partNumber, it.capacity, it.mfgDate, it.note)
                            .joinToString(",") { v -> cell(v) }
                    ).append('\n')
                }
                f.writeText(sb.toString(), Charsets.UTF_8); f
            }
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ctx.startActivity(Intent.createChooser(intent, "اشتراک‌گذاری جدول").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
