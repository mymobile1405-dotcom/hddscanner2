package com.example.hddscanner

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "hdd")
data class HddEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val brand: String = "",
    val model: String = "",
    val type: String = "",
    val serial: String = "",
    val partNumber: String = "",
    val capacity: String = "",
    val mfgDate: String = "",
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface HddDao {
    @Query("SELECT * FROM hdd ORDER BY id DESC")
    fun all(): Flow<List<HddEntry>>

    @Query("SELECT * FROM hdd ORDER BY id DESC")
    suspend fun snapshot(): List<HddEntry>

    @Insert
    suspend fun insert(e: HddEntry)

    @Update
    suspend fun update(e: HddEntry)

    @Delete
    suspend fun delete(e: HddEntry)

    @Query("SELECT COUNT(*) FROM hdd WHERE serial = :serial AND serial != '' AND id != :excludeId")
    suspend fun countSerial(serial: String, excludeId: Long): Int
}

@Database(entities = [HddEntry::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): HddDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "hdd2.db")
                .build().also { inst = it }
        }
    }
}
