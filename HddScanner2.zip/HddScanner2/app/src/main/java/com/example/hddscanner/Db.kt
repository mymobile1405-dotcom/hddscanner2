package com.example.hddscanner

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "hdd")
data class HddEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val brand: String = "",
    val model: String = "",
    val type: String = "",
    val serial: String = "",
    val partNumber: String = "",
    val capacity: String = "",
    val mfgDate: String = "",
    val note: String = "",
    val status: String = "",        // GREEN / YELLOW / ORANGE / MANUAL ...
    val similarity: Double = 0.0,   // شباهت OCR و بارکد (۰ تا ۱)
    val source: String = "",        // BARCODE+OCR / OCR / BARCODE / MANUAL
    val raw: String = "",           // متن خام OCR و بارکدها برای عیب‌یابی
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface HddDao {
    @Query("SELECT * FROM hdd ORDER BY id DESC")
    fun all(): Flow<List<HddEntry>>

    @Query("SELECT * FROM hdd ORDER BY id DESC")
    suspend fun snapshot(): List<HddEntry>

    @Insert
    suspend fun insert(e: HddEntry)

    @Update
    suspend fun update(e: HddEntry)

    @Delete
    suspend fun delete(e: HddEntry)
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE hdd ADD COLUMN status TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE hdd ADD COLUMN similarity REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE hdd ADD COLUMN source TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE hdd ADD COLUMN raw TEXT NOT NULL DEFAULT ''")
    }
}

@Database(entities = [HddEntry::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): HddDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "hdd2.db")
                .addMigrations(MIGRATION_1_2)
                .build().also { inst = it }
        }
    }
}
