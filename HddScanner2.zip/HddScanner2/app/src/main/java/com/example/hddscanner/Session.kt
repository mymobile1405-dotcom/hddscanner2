package com.example.hddscanner

import android.os.SystemClock

class Votes {
    private val m = HashMap<String, Int>()
    var total = 0
        private set

    fun add(v: String?, w: Int = 1) {
        if (v.isNullOrBlank()) return
        m[v] = (m[v] ?: 0) + w
        total += w
    }

    fun top(): Pair<String, Int>? = m.maxByOrNull { it.value }?.let { it.key to it.value }
    fun all(): Map<String, Int> = m
}

data class TopSerial(val value: String, val count: Int, val ambiguous: Boolean)

/**
 * رأی‌گیری سریال: خوانش‌هایی که فقط در کاراکترهای شبیه هم (0/O، 1/I، 5/S، 8/B) فرق دارند
 * در یک گروه می‌روند و کاراکتر نهایی «حرف‌به‌حرف» با اکثریت انتخاب می‌شود.
 * اگر در یک موقعیت اکثریت واضح (≥۷۰٪) نبود، نتیجه «مبهم» علامت می‌خورد.
 */
class SerialVotes {
    private val groups = HashMap<String, HashMap<String, Int>>()
    var total = 0
        private set

    fun add(s: String?, w: Int = 1) {
        if (s.isNullOrBlank()) return
        val g = groups.getOrPut(SerialRules.canon(s)) { HashMap() }
        g[s] = (g[s] ?: 0) + w
        total += w
    }

    fun top(): TopSerial? {
        val variants = groups.values.maxByOrNull { it.values.sum() } ?: return null
        val n = variants.values.sum()
        val len = variants.keys.first().length
        val sb = StringBuilder()
        var ambiguous = false
        for (i in 0 until len) {
            val c = HashMap<Char, Int>()
            variants.forEach { (v, cnt) -> if (v.length == len) c[v[i]] = (c[v[i]] ?: 0) + cnt }
            val best = c.maxByOrNull { it.value }!!
            if (best.value * 100 / n < 60) ambiguous = true
            sb.append(best.key)
        }
        return TopSerial(sb.toString(), n, ambiguous)
    }
}

sealed interface Decision {
    data object Pending : Decision
    data class Ok(val fields: Map<String, String>, val status: String) : Decision
    data class Problem(val reason: String) : Decision
}

class Session {
    private val vBrand = Votes(); private val vModel = Votes(); private val vPn = Votes()
    private val vCap = Votes(); private val vMfg = Votes()
    private val vOcr = SerialVotes(); private val vBc = Votes()
    var labelFrames = 0
        private set
    private var firstAt = 0L

    fun add(p: Parsed, w: Int = 1) {
        if (labelFrames == 0) firstAt = SystemClock.elapsedRealtime()
        labelFrames++
        vBrand.add(p.brand, w); vModel.add(p.model, w); vPn.add(p.pn, w)
        vCap.add(p.capacity, w); vMfg.add(p.mfg, w)
        vOcr.add(p.ocrSerial, w)
        p.bcSerials.forEach { vBc.add(it, w) }
    }

    /** اگر بارکدی با سریال OCR یکی باشد (با تحمل 0/O و ...)، متن دقیق بارکد برمی‌گردد */
    private fun barcodeFor(serial: String): Map.Entry<String, Int>? =
        vBc.all().entries.filter { SerialRules.canon(it.key) == SerialRules.canon(serial) }
            .maxByOrNull { it.value }

    fun best(): Map<String, String> {
        val out = linkedMapOf<String, String>()
        vBrand.top()?.let { out[F.BRAND] = it.first }
        vModel.top()?.let { out[F.MODEL] = it.first }
        val o = vOcr.top()
        val serial = if (o != null) (barcodeFor(o.value)?.key ?: o.value) else vBc.top()?.first
        serial?.let { out[F.SERIAL] = it }
        vPn.top()?.let { out[F.PN] = it.first }
        vCap.top()?.let { out[F.CAPACITY] = it.first }
        vMfg.top()?.let { out[F.MFG] = it.first }
        return out
    }

    /**
     * قوانین پذیرش:
     *  - VERIFIED: ≥۲ فریم یکسان از S/N + بارکدی که همان سریال را تأیید کند
     *  - OCR: S/N بدون بارکد، ≥۳ فریم و ≥۷۰٪ اجماع (اگر قالب با برند نخواند: ≥۵ فریم و ≥۸۰٪) و بدون ابهام حرفی
     *  - REVIEW: فقط بارکد دیده شده (بدون S/N) یا مدل خوانده نشده؛ ثبت می‌شود ولی علامت «نیاز به بررسی» می‌خورد
     *  اگر ۱۰ ثانیه هیچ‌کدام پیش نیامد: مشکل (بوق هشدار) و ثبت نمی‌شود.
     */
    fun decide(now: Long): Decision {
        val model = vModel.top()?.first
        val brand = vBrand.top()?.first
        val o = vOcr.top()

        var serial: String? = null
        var status = ""
        if (o != null) {
            val bc = barcodeFor(o.value)
            val share = o.count * 100 / vOcr.total
            val fmtOk = SerialRules.valid(brand, o.value)
            if (bc != null && o.count >= 2) {
                serial = bc.key; status = St.VERIFIED
            } else if (!o.ambiguous && o.count >= (if (fmtOk) 3 else 5) && share >= (if (fmtOk) 70 else 80)) {
                serial = o.value; status = St.OCR
            }
        } else {
            val cands = vBc.all().filter { SerialRules.valid(brand, it.key) && it.value >= 3 }
            if (brand != null && cands.size == 1) {
                serial = cands.keys.first(); status = St.REVIEW
            }
        }
        if (serial != null) {
            if (model == null) status = St.REVIEW
            return Decision.Ok(best() + (F.SERIAL to serial), status)
        }

        if (labelFrames >= 3 && now - firstAt > 10_000) {
            val reason = when {
                o == null && vBc.top() != null -> "سریال جلوی S/N پیدا نشد (فقط بارکد دیده شد)؛ نزدیک‌تر بگیر"
                o == null -> "سریال خوانده نشد؛ نور، فاصله یا زاویه را تغییر بده"
                o.ambiguous -> "حروف مشابه (0/O، 1/I، 5/S) قطعی نشد؛ واضح‌تر و ثابت‌تر بگیر"
                else -> "سریال ناپایدار است؛ دوربین را ثابت نگه دار"
            }
            return Decision.Problem(reason)
        }
        return Decision.Pending
    }
}
