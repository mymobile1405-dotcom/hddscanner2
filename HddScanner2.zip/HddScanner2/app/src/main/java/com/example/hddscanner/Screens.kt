@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.hddscanner

import android.Manifest
import android.content.pm.PackageManager
import android.util.Size
import android.view.MotionEvent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.util.concurrent.Executors

private val labels = mapOf(
    F.BRAND to "برند", F.MODEL to "مدل", F.SERIAL to "سریال (S/N)",
    F.PN to "پارت‌نامبر (P/N)", F.CAPACITY to "ظرفیت", F.MFG to "تاریخ ساخت",
    F.NOTE to "یادداشت (محل / وضعیت / ...)"
)

@Composable
private fun FieldBox(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        singleLine = true, modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun ScanScreen(vm: ScanViewModel) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { ScanProcessor.processUri(ctx, it) { t, c -> vm.onPhoto(t, c) } }
    }
    LaunchedEffect(Unit) { if (!granted) permLauncher.launch(Manifest.permission.CAMERA) }

    val fields by vm.fields.collectAsStateWithLifecycle()
    val frames by vm.frames.collectAsStateWithLifecycle()
    val verdict by vm.verdict.collectAsStateWithLifecycle()
    val raw by vm.raw.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    val clipboard = LocalClipboardManager.current
    LaunchedEffect(verdict.level) { if (verdict.level == Level.GREEN) haptic.performHapticFeedback(HapticFeedbackType.LongPress) }

    var camera by remember { mutableStateOf<Camera?>(null) }
    var torch by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(0f) }
    var showRaw by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().weight(1f)) {
            if (granted) {
                CameraPreview(vm, Modifier.fillMaxSize()) { camera = it }
                if (camera?.cameraInfo?.hasFlashUnit() == true) {
                    IconButton(
                        onClick = { torch = !torch; camera?.cameraControl?.enableTorch(torch) },
                        modifier = Modifier.align(Alignment.TopEnd)
                    ) {
                        Icon(if (torch) Icons.Default.FlashOn else Icons.Default.FlashOff, "فلش", tint = Color.White)
                    }
                }
                Slider(
                    value = zoom,
                    onValueChange = { zoom = it; camera?.cameraControl?.setLinearZoom(it) },
                    modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 56.dp)
                )
            } else {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }) { Text("اجازه دسترسی به دوربین") }
                }
            }
        }
        val look = levelLook(verdict.level)
        Surface(color = look.color, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                val pct = if (verdict.similarity > 0) "  ${(verdict.similarity * 100).toInt()}٪" else ""
                Text(look.title + pct, color = look.text, style = MaterialTheme.typography.titleSmall)
                if (verdict.reason.isNotBlank()) {
                    Text(verdict.reason, color = look.text, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Column(
            Modifier.fillMaxWidth().weight(1.5f).verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "فریم‌های خوانده‌شده: $frames — دوربین را ثابت نگه دارید؛ برای دقت بیشتر روی لیبل تپ (فوکوس) و زوم کنید.",
                style = MaterialTheme.typography.labelMedium
            )
            listOf(F.BRAND, F.MODEL).forEach { k ->
                FieldBox(labels[k] ?: k, fields[k].orEmpty()) { vm.edit(k, it) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("نوع:")
                listOf("HDD", "SSD").forEach { t ->
                    FilterChip(selected = fields[F.TYPE] == t, onClick = { vm.edit(F.TYPE, t) }, label = { Text(t) })
                }
            }
            listOf(F.SERIAL, F.PN, F.CAPACITY, F.MFG, F.NOTE).forEach { k ->
                FieldBox(labels[k] ?: k, fields[k].orEmpty()) { vm.edit(k, it) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = vm::save, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("ثبت در جدول")
                }
                OutlinedButton(onClick = { picker.launch("image/*") }) { Icon(Icons.Default.Image, "انتخاب عکس از گالری") }
                OutlinedButton(onClick = vm::reset) { Icon(Icons.Default.Refresh, "پاک کردن و اسکن بعدی") }
            }
            TextButton(onClick = { showRaw = !showRaw }) {
                Text(if (showRaw) "پنهان کردن متن خام" else "نمایش متن خام OCR (برای عیب‌یابی)")
            }
            if (showRaw) {
                Text(raw, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
                TextButton(onClick = { clipboard.setText(AnnotatedString(raw)) }) { Text("کپی متن خام") }
            }
        }
    }
}

@Composable
private fun CameraPreview(vm: ScanViewModel, modifier: Modifier, onCamera: (Camera) -> Unit) {
    val owner = LocalLifecycleOwner.current
    val executor = remember { Executors.newSingleThreadExecutor() }
    val holder = remember { arrayOfNulls<ProcessCameraProvider>(1) }
    // هنگام خروج از تب اسکن، دوربین آزاد می‌شود (جلوگیری از کرش و مصرف باتری)
    DisposableEffect(Unit) {
        onDispose { holder[0]?.unbindAll(); executor.shutdown() }
    }

    AndroidView(modifier = modifier, factory = { c ->
        val previewView = PreviewView(c).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        var cam: Camera? = null
        previewView.setOnTouchListener { v, ev ->
            if (ev.action == MotionEvent.ACTION_UP) {
                cam?.let {
                    val p = previewView.meteringPointFactory.createPoint(ev.x, ev.y)
                    it.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(p).build())
                }
                v.performClick()
            }
            true
        }
        val future = ProcessCameraProvider.getInstance(c)
        future.addListener({
            val provider = future.get()
            holder[0] = provider
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setResolutionSelector(
                    ResolutionSelector.Builder()
                        .setResolutionStrategy(
                            ResolutionStrategy(Size(1920, 1080), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                        ).build()
                ).build()
            analysis.setAnalyzer(executor) { proxy ->
                ScanProcessor.processProxy(proxy) { t, codes -> vm.onFrame(t, codes) }
            }
            provider.unbindAll()
            val bound = provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            cam = bound
            onCamera(bound)
        }, ContextCompat.getMainExecutor(c))
        previewView
    })
}

@Composable
fun TableScreen(vm: ScanViewModel) {
    val ctx = LocalContext.current
    val list by vm.entries.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<HddEntry?>(null) }
    var deleting by remember { mutableStateOf<HddEntry?>(null) }

    val filtered = remember(list, query) {
        if (query.isBlank()) list else list.filter { e ->
            listOf(e.brand, e.model, e.type, e.serial, e.partNumber, e.capacity, e.note)
                .any { it.contains(query.trim(), ignoreCase = true) }
        }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (query.isBlank()) "تعداد: ${list.size}" else "نتیجه: ${filtered.size} از ${list.size}",
                Modifier.weight(1f), style = MaterialTheme.typography.titleMedium
            )
            Button(onClick = { vm.exportCsv(ctx) }, enabled = list.isNotEmpty()) {
                Icon(Icons.Default.Share, null); Spacer(Modifier.width(4.dp)); Text("خروجی CSV")
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            label = { Text("جستجو (مدل، سریال، برند، یادداشت...)") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { e ->
                Card(onClick = { editing = e }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${e.brand} ${e.model}".trim(), style = MaterialTheme.typography.titleSmall)
                            Text(listOf(e.type, e.capacity).filter { it.isNotBlank() }.joinToString(" • "))
                            if (e.serial.isNotBlank()) Text("S/N: ${e.serial}")
                            if (e.partNumber.isNotBlank()) Text("P/N: ${e.partNumber}")
                            if (e.mfgDate.isNotBlank()) Text("تاریخ ساخت: ${e.mfgDate}")
                            if (e.status.isNotBlank()) Text(statusText(e))
                            if (e.note.isNotBlank()) Text("📝 ${e.note}")
                        }
                        IconButton(onClick = { deleting = e }) { Icon(Icons.Default.Delete, "حذف") }
                    }
                }
            }
        }
    }

    editing?.let { e ->
        EditDialog(e, onDismiss = { editing = null }) { vm.update(it); editing = null }
    }
    deleting?.let { e ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("حذف مورد") },
            text = { Text("«${e.model.ifBlank { e.serial }}» حذف شود؟") },
            confirmButton = { TextButton(onClick = { vm.delete(e); deleting = null }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun EditDialog(e: HddEntry, onDismiss: () -> Unit, onSave: (HddEntry) -> Unit) {
    var brand by remember { mutableStateOf(e.brand) }
    var model by remember { mutableStateOf(e.model) }
    var type by remember { mutableStateOf(e.type) }
    var serial by remember { mutableStateOf(e.serial) }
    var pn by remember { mutableStateOf(e.partNumber) }
    var cap by remember { mutableStateOf(e.capacity) }
    var mfg by remember { mutableStateOf(e.mfgDate) }
    var note by remember { mutableStateOf(e.note) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ویرایش") },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    e.copy(
                        brand = brand.trim(), model = model.trim(), type = type.trim(), serial = serial.trim(),
                        partNumber = pn.trim(), capacity = cap.trim(), mfgDate = mfg.trim(), note = note.trim()
                    )
                )
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                FieldBox("برند", brand) { brand = it }
                FieldBox("مدل", model) { model = it }
                FieldBox("نوع (HDD / SSD)", type) { type = it }
                FieldBox("سریال", serial) { serial = it }
                FieldBox("پارت‌نامبر", pn) { pn = it }
                FieldBox("ظرفیت", cap) { cap = it }
                FieldBox("تاریخ ساخت", mfg) { mfg = it }
                FieldBox("یادداشت", note) { note = it }
            }
        }
    )
}

private class Look(val color: Color, val text: Color, val title: String)

private fun levelLook(l: Level): Look = when (l) {
    Level.GREEN -> Look(Color(0xFF2E7D32), Color.White, "✓ تأییدشده (OCR + بارکد)")
    Level.YELLOW -> Look(Color(0xFFF9A825), Color.Black, "! بررسی کن")
    Level.ORANGE -> Look(Color(0xFFEF6C00), Color.Black, "! فقط بارکد خوانده شد")
    Level.RED -> Look(Color(0xFFC62828), Color.White, "✕ مشکل")
    Level.BLUE -> Look(Color(0xFF1565C0), Color.White, "⧉ تکراری")
    Level.PENDING -> Look(Color(0xFF616161), Color.White, "در حال خواندن…")
}

private fun statusText(e: HddEntry): String {
    val label = when (e.status) {
        "GREEN" -> "✓ تأییدشده"
        "YELLOW" -> "! نیاز به بررسی (OCR)"
        "ORANGE" -> "! نیاز به بررسی (بارکد)"
        "MANUAL" -> "✎ دستی"
        else -> e.status
    }
    val pct = if (e.similarity > 0) " — شباهت ${(e.similarity * 100).toInt()}٪" else ""
    return label + pct
}
