package com.example.hddscanner

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : ComponentActivity() {
    private val vm: ScanViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                var tab by rememberSaveable { mutableStateOf(0) }
                val snack = remember { SnackbarHostState() }
                val msg by vm.message.collectAsStateWithLifecycle()
                LaunchedEffect(msg) { msg?.let { snack.showSnackbar(it); vm.clearMessage() } }

                Scaffold(
                    snackbarHost = { SnackbarHost(snack) },
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.CameraAlt, null) }, label = { Text("اسکن") })
                            NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.TableChart, null) }, label = { Text("جدول") })
                        }
                    }
                ) { pad ->
                    Surface(Modifier.padding(pad).fillMaxSize()) {
                        if (tab == 0) ScanScreen(vm) else TableScreen(vm)
                    }
                }
            }
        }
    }
}
