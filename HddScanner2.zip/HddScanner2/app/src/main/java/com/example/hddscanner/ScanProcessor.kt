package com.example.hddscanner

import android.content.Context
import android.net.Uri
import androidx.camera.core.ImageProxy
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

object ScanProcessor {
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    // فقط فرمت‌هایی که روی لیبل دیسک‌ها هست؛ سریع‌تر و دقیق‌تر از اسکن همه فرمت‌ها
    private val scanner by lazy {
        BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder().setBarcodeFormats(
                Barcode.FORMAT_CODE_128, Barcode.FORMAT_CODE_39, Barcode.FORMAT_CODE_93,
                Barcode.FORMAT_DATA_MATRIX, Barcode.FORMAT_QR_CODE, Barcode.FORMAT_PDF417
            ).build()
        )
    }
    @Volatile private var last = 0L

    private fun run(img: InputImage, done: () -> Unit = {}, onResult: (String, List<String>) -> Unit) {
        val t1 = recognizer.process(img)
        val t2 = scanner.process(img)
        Tasks.whenAllComplete(t1, t2).addOnCompleteListener {
            val text = if (t1.isSuccessful) t1.result.text else ""
            val codes = if (t2.isSuccessful) t2.result.mapNotNull { it.rawValue } else emptyList()
            onResult(text, codes)
            done()
        }
    }

    @androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
    fun processProxy(proxy: ImageProxy, onResult: (String, List<String>) -> Unit) {
        val media = proxy.image
        val now = System.currentTimeMillis()
        if (media == null || now - last < 600) { proxy.close(); return }
        last = now
        val img = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        run(img, done = { proxy.close() }, onResult = onResult)
    }

    fun processUri(ctx: Context, uri: Uri, onResult: (String, List<String>) -> Unit) {
        val img = try { InputImage.fromFilePath(ctx, uri) } catch (e: Exception) { return }
        run(img, onResult = onResult)
    }
}
