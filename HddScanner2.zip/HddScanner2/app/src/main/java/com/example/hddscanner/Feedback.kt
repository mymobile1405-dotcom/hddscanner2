package com.example.hddscanner

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.VibrationEffect
import android.os.Vibrator
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.sin

/**
 * بوق‌ها را خود اپ تولید می‌کند (موج سینوسی PCM) تا به ToneGenerator و تنظیمات سازنده وابسته نباشد.
 *  - ثبت موفق: ۱ بوق بلند و زیر
 *  - تکراری: ۲ بوق کوتاه
 *  - مشکل/ناخوانا: ۳ بوق بم و طولانی (هشدار)
 * صدا روی ولوم «رسانه» پخش می‌شود.
 */
class Feedback(ctx: Context) {
    var enabled = true
    private val vib: Vibrator? = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    private val pool = Executors.newSingleThreadExecutor()

    private companion object {
        const val SR = 22050
    }

    private fun tone(freq: Double, ms: Int): ShortArray {
        val n = SR * ms / 1000
        val fade = SR * 8 / 1000
        return ShortArray(n) { i ->
            val env = when {
                i < fade -> i.toDouble() / fade
                i > n - fade -> (n - i).toDouble() / fade
                else -> 1.0
            }
            (sin(2 * PI * freq * i / SR) * env * 0.9 * Short.MAX_VALUE).toInt().toShort()
        }
    }

    private fun silence(ms: Int) = ShortArray(SR * ms / 1000)

    private fun join(vararg parts: ShortArray): ShortArray {
        val out = ShortArray(parts.sumOf { it.size })
        var p = 0
        for (a in parts) { a.copyInto(out, p); p += a.size }
        return out
    }

    private fun play(pcm: ShortArray) {
        pool.execute {
            try {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val fmt = AudioFormat.Builder()
                    .setSampleRate(SR)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
                val track = AudioTrack(attrs, fmt, pcm.size * 2, AudioTrack.MODE_STATIC, AudioManager.AUDIO_SESSION_ID_GENERATE)
                track.write(pcm, 0, pcm.size)
                track.play()
                Thread.sleep(pcm.size * 1000L / SR + 150)
                track.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun vibrate(pattern: LongArray) {
        try { vib?.vibrate(VibrationEffect.createWaveform(pattern, -1)) } catch (_: Exception) {}
    }

    fun ok(force: Boolean = false) {
        if (!enabled && !force) return
        play(tone(1500.0, 170))
        vibrate(longArrayOf(0, 70))
    }

    fun duplicate(force: Boolean = false) {
        if (!enabled && !force) return
        play(join(tone(1000.0, 110), silence(110), tone(1000.0, 110)))
        vibrate(longArrayOf(0, 70, 120, 70))
    }

    fun error(force: Boolean = false) {
        if (!enabled && !force) return
        play(join(tone(450.0, 280), silence(150), tone(450.0, 280), silence(150), tone(450.0, 280)))
        vibrate(longArrayOf(0, 300, 150, 300, 150, 300))
    }

    fun release() { pool.shutdown() }
}
