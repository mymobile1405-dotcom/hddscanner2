package com.example.hddscanner

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator

/** مدیریت بوق و لرزش؛ صدا از ولوم رسانه پخش می‌شود */
class Feedback(private val ctx: Context) {

    enum class Mode { ALL, ALERTS, SILENT }

    private val prefs = ctx.getSharedPreferences("hdd_prefs", Context.MODE_PRIVATE)
    private var tone: ToneGenerator? = null
    private var lastAt = 0L

    var mode: Mode = try {
        Mode.valueOf(prefs.getString("mode", Mode.ALL.name) ?: Mode.ALL.name)
    } catch (e: Exception) {
        Mode.ALL
    }
        set(value) {
            field = value
            prefs.edit().putString("mode", value.name).apply()
        }

    var vibrate: Boolean = prefs.getBoolean("vibrate", true)
        set(value) {
            field = value
            prefs.edit().putBoolean("vibrate", value).apply()
        }

    /** هر وضعیت فقط در لحظه ورود صدا می‌دهد؛ حداقل ۱٫۵ ثانیه بین دو بوق */
    fun play(level: Level, force: Boolean = false) {
        if (level == Level.PENDING) return
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastAt < 1500) return
        lastAt = now
        val isAlert = level != Level.GREEN
        if (mode == Mode.ALL || (mode == Mode.ALERTS && isAlert)) beep(level)
        if (vibrate) buzz(level)
    }

    private fun beep(level: Level) {
        try {
            if (tone == null) tone = ToneGenerator(AudioManager.STREAM_MUSIC, 100)
            val type = when (level) {
                Level.GREEN -> ToneGenerator.TONE_PROP_ACK
                Level.YELLOW, Level.ORANGE -> ToneGenerator.TONE_PROP_BEEP
                Level.BLUE -> ToneGenerator.TONE_PROP_BEEP2
                Level.RED -> ToneGenerator.TONE_SUP_ERROR
                Level.PENDING -> return
            }
            tone?.startTone(type, 300)
        } catch (e: Exception) {
            // دستگاه بدون صدا یا خطای سیستم: بی‌صدا ادامه می‌دهیم
        }
    }

    @Suppress("DEPRECATION")
    private fun buzz(level: Level) {
        try {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            val pattern = when (level) {
                Level.GREEN -> longArrayOf(0, 80)
                Level.YELLOW, Level.ORANGE -> longArrayOf(0, 200)
                Level.BLUE -> longArrayOf(0, 100, 100, 100)
                Level.RED -> longArrayOf(0, 600)
                Level.PENDING -> return
            }
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                v.vibrate(pattern, -1)
            }
        } catch (e: Exception) {
            // بدون مجوز یا بدون موتور لرزش
        }
    }

    fun release() {
        try { tone?.release() } catch (e: Exception) { }
        tone = null
    }
}
