package com.example.hddscanner

import java.util.Locale

object F {
    const val BRAND = "brand"
    const val MODEL = "model"
    const val TYPE = "type"
    const val SERIAL = "serial"
    const val PN = "pn"
    const val CAPACITY = "capacity"
    const val MFG = "mfg"
    const val NOTE = "note"
    val all = listOf(BRAND, MODEL, TYPE, SERIAL, PN, CAPACITY, MFG, NOTE)
}

object LabelParser {

    private val modelPatterns = listOf(
        Regex("""\bWDS\d{3,4}[GT]\d[A-Z0-9]{3,6}\b"""),                   // WDS500G2B0A
        Regex("""\bWD\d{2,4}[A-Z]{4}(?:-[A-Z0-9]{2,7})?\b"""),            // WD10EZEX-00BN5A0
        Regex("""\bST[39]\d{6,7}[A-Z]{1,2}\b"""),                         // ST3500418AS
        Regex("""\bST\d{3,5}[A-Z]{2}\d{3}\b"""),                          // ST1000DM010
        Regex("""\b(?:DT|MQ)\d{2}[A-Z]{3}\d{3}\b"""),                     // DT01ACA100
        Regex("""\bHDW[A-Z]\d{3}[A-Z]{0,6}\b"""),                         // HDWD110EZSTA
        Regex("""\bMZ-[A-Z0-9]{6,10}\b"""),                               // MZ-76E500B
        Regex("""\bSA\d{3}S3\d?/?\d{1,4}[GT]\b"""),                       // SA400S37/480G
        Regex("""\b(?:HUS|HUH|HTS|HDS|HUA)\d{6,8}[A-Z0-9]*\b"""),         // HGST / Hitachi
        Regex("""\bCT\d{3,4}[A-Z0-9]{4,12}\b"""),                         // CT500MX500SSD1
        Regex("""\bSDSSD[A-Z0-9-]{5,14}\b""")                             // SDSSDA-240G-G26
    )
    private val modelLabeled =
        Regex("""\b(?:MODEL|MDL)\s*(?:NO\.?|NUMBER)?\s*[:#]?\s*([A-Z0-9][A-Z0-9\-/]{4,20})""")
    private val serialLabeled =
        Regex("""\b(?:S\s?/\s?N|5\s?/\s?N|SN|S\.N|SERIAL\s*(?:NO\.?|NUMBER|#)?)\s*[:#.]?\s*([A-Z0-9][A-Z0-9\-]{5,19})""")
    private val pnLabeled =
        Regex("""\b(?:P/N|PN|PART\s*(?:NO\.?|NUMBER)?)\s*[:#.]?\s*([A-Z0-9][A-Z0-9\-]{4,20})""")
    private val capacityRx = Regex("""\b(\d{1,2}(?:[.,]\d{1,2})?|\d{3,5})\s?(TB|GB)\b(?!\s?/)""")
    private val dateRx = Regex(
        """\b(?:DATE|DOM|MFG|MFD|DCM)\w*\s*[:.]?\s*(\d{1,2}[-/. ]+[A-Z]{3}[-/. ]+\d{2,4}|\d{2}[-/.]\d{2}[-/.]\d{2,4}|\d{4}[-/.]\d{2}[-/.]\d{2})"""
    )
    private val legacyWd4 = setOf(1200, 1600, 2500, 3200, 5000, 6400, 7500)

    data class Ocr(
        val model: String? = null, val pn: String? = null, val serial: String? = null,
        val capacity: String? = null, val mfg: String? = null,
        val brand: String? = null, val type: String? = null,
        val multi: Boolean = false      // چند لیبل/چند سریال متفاوت در یک تصویر
    )

    /** آیا این متن شبیه کد مدل است؟ (برای حذف بارکدهای مدل از نامزدهای سریال) */
    fun looksLikeModel(s: String): Boolean {
        val u = s.uppercase(Locale.ROOT)
        return modelPatterns.any { it.matches(u) }
    }

    /** فقط خروجی OCR؛ مقایسه با بارکد کار SerialDecider است */
    fun ocr(rawText: String): Ocr {
        val text = rawText.uppercase(Locale.ROOT).replace(Regex("""\s+"""), " ")
        val model = modelPatterns.firstNotNullOfOrNull { it.find(text)?.value }
            ?: modelLabeled.find(text)?.groupValues?.get(1)?.takeIf { m -> m.any(Char::isDigit) }
        val pn = pnLabeled.find(text)?.groupValues?.get(1)?.takeIf { it != model }
        val serials = serialLabeled.findAll(text).map { it.groupValues[1] }
            .filter { it != model && it != pn }.toList()
        val serial = serials.firstOrNull()
        val cap = capacityRx.findAll(text).firstNotNullOfOrNull { m ->
            val v = m.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return@firstNotNullOfOrNull null
            val gb = if (m.groupValues[2] == "TB") v * 1000 else v
            if (gb in 16.0..30000.0) gb else null
        } ?: model?.let { capacityFromModel(it) }
        return Ocr(
            model = model, pn = pn, serial = serial,
            capacity = cap?.let { formatCapacity(it) },
            mfg = dateRx.find(text)?.groupValues?.get(1),
            brand = detectBrand(text, model),
            type = detectType(text, model),
            multi = multiLabel(text, serials)
        )
    }

    /** اگر در یک تصویر دو مدل یا دو سریال کاملاً متفاوت دیده شود، یعنی چند لیبل (و خطر قاطی شدن) */
    private fun multiLabel(text: String, serials: List<String>): Boolean {
        val norms = modelPatterns.flatMap { rx -> rx.findAll(text).map { it.value }.toList() }
            .map { Sim.norm(it) }.distinct()
        val maximal = norms.filter { a -> norms.none { b -> b != a && b.startsWith(a) } }
        val multiSerial = serials.any { a -> serials.any { b -> Sim.score(a, b).similarity < 0.5 } }
        return maximal.size > 1 || multiSerial
    }

    private fun detectBrand(t: String, model: String?): String? = when {
        "WESTERN DIGITAL" in t || model?.startsWith("WD") == true -> "Western Digital"
        "SEAGATE" in t || model?.startsWith("ST") == true -> "Seagate"
        "TOSHIBA" in t || (model != null && Regex("^(DT|MQ|HDW)").containsMatchIn(model)) -> "Toshiba"
        "SAMSUNG" in t || model?.startsWith("MZ-") == true -> "Samsung"
        "KINGSTON" in t || (model != null && Regex("^SA\\d").containsMatchIn(model)) -> "Kingston"
        "HGST" in t || "HITACHI" in t || (model != null && Regex("^H(US|UH|TS|DS|UA)").containsMatchIn(model)) -> "HGST/Hitachi"
        "CRUCIAL" in t || (model != null && Regex("^CT\\d").containsMatchIn(model)) -> "Crucial"
        "SANDISK" in t || model?.startsWith("SDSSD") == true -> "SanDisk"
        else -> null
    }

    private fun detectType(t: String, model: String?): String? = when {
        model != null && Regex("^(WDS|MZ-|SA\\d|CT\\d|SDSSD)").containsMatchIn(model) -> "SSD"
        "SSD" in t || "SOLID STATE" in t -> "SSD"
        model != null -> "HDD"
        "HDD" in t || "HARD DISK" in t || "HARD DRIVE" in t -> "HDD"
        else -> null
    }

    /** ظرفیت (به GB) از روی کد مدل برندهای رایج */
    fun capacityFromModel(model: String): Double? {
        Regex("""^WDS(\d{3,4})([GT])""").find(model)?.let {
            val n = it.groupValues[1].toDouble()
            return if (it.groupValues[2] == "T") n * 10 else n                // 100T → 1TB
        }
        Regex("""^WD(\d{2,4})[A-Z]{2}""").find(model)?.let {
            val d = it.groupValues[1]; val n = d.toInt()
            return when (d.length) {
                2 -> n * 100.0                                                // WD10→1TB, WD40→4TB
                3 -> if (n in 100..299) (n / 10) * 1000.0 else n / 10.0       // WD120→12TB, WD800→80GB
                else -> when {
                    n in legacyWd4 -> n / 10.0                                // WD5000→500GB
                    n / 1000 == 5 -> 500.0                                    // WD5003→500GB
                    n % 1000 < 10 -> (n / 1000) * 1000.0                      // WD1003→1TB, WD4000→4TB
                    else -> n / 10.0
                }
            }
        }
        Regex("""^ST[39](\d{3,4})\d{3}[A-Z]{1,2}$""").find(model)?.let { return it.groupValues[1].toDouble() }
        Regex("""^ST(\d{3,5})[A-Z]{2}""").find(model)?.let { return it.groupValues[1].toDouble() }
        Regex("""^(?:DT|MQ)\d{2}[A-Z]{3}(\d{3})""").find(model)?.let { return it.groupValues[1].toInt() * 10.0 }
        Regex("""^HDW[A-Z]\d(\d)0""").find(model)?.let { return it.groupValues[1].toInt() * 1000.0 }
        Regex("""^MZ-[A-Z0-9]{3}(\d)T0""").find(model)?.let { return it.groupValues[1].toInt() * 1000.0 }
        Regex("""^MZ-[A-Z0-9]{3}(\d{3})""").find(model)?.let { return it.groupValues[1].toDouble() }
        Regex("""/(\d{1,4})([GT])$""").find(model)?.let {
            return it.groupValues[1].toDouble() * (if (it.groupValues[2] == "T") 1000 else 1)
        }
        Regex("""^CT(\d{3,4})[A-Z]""").find(model)?.let { return it.groupValues[1].toDouble() }
        Regex("""^SDSSD[A-Z0-9]*-(\d{2,4})([GT])""").find(model)?.let {
            return it.groupValues[1].toDouble() * (if (it.groupValues[2] == "T") 1000 else 1)
        }
        return null
    }

    fun formatCapacity(gb: Double): String =
        if (gb >= 1000) {
            val tb = gb / 1000
            (if (tb % 1.0 == 0.0) tb.toInt().toString() else "%.1f".format(Locale.US, tb)) + " TB"
        } else "${gb.toInt()} GB"
}
