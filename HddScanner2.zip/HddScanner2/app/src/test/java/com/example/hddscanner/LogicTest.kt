package com.example.hddscanner

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LogicTest {

    private fun ocr(serial: String?, model: String? = "WD10EZEX-00BN5A0", brand: String? = "Western Digital") =
        LabelParser.Ocr(model = model, pn = null, serial = serial, brand = brand, type = "HDD")

    // ---------- موتور شباهت ----------

    @Test fun confusableCharsAreStrongMatch() {
        val sc = Sim.score("WX12A345", "WXI2A345")
        assertTrue(sc.similarity >= 0.95)
        assertTrue(Sim.isStrong(sc, 8))
    }

    @Test fun differentSerialsAreFarApart() {
        assertTrue(Sim.score("WX12A345", "ZZ99B000").similarity < 0.5)
    }

    @Test fun oneRealErrorIsStillStrongForLongSerial() {
        val sc = Sim.score("WX12A345", "WX12A346")
        assertTrue(sc.similarity >= 0.85)
        assertTrue(Sim.isStrong(sc, 8))
    }

    @Test fun twoRealErrorsAreNotCandidates() {
        assertTrue(Sim.score("WX12A345", "WX12B346").similarity < 0.80)
    }

    @Test fun oneErrorInShortSerialIsNotStrong() {
        val sc = Sim.score("ABC123", "ABC124")
        assertFalse(Sim.isStrong(sc, 6))
    }

    @Test fun extraPrefixOnBarcodeIsCandidateButNotStrong() {
        val sc = Sim.score("WX12A345", "SWX12A345")
        assertTrue(sc.similarity >= 0.90)
        assertFalse(sc.sameLength)
        assertFalse(Sim.isStrong(sc, 8))
    }

    @Test fun hyphensAndSpacesAreIgnored() {
        assertEquals(1.0, Sim.score("WD-WCC4N1234567", "WDWCC4N1234567").similarity, 1e-9)
    }

    @Test fun multiFieldBarcodeIsSplitIntoTokens() {
        val t = Sim.tokens("SN:WX12A345;PN:ABCD-1234")
        assertTrue(t.contains("WX12A345"))
        assertTrue(t.contains("ABCD-1234"))
    }

    // ---------- OCR ----------

    @Test fun ocrReadsWdLabel() {
        val o = LabelParser.ocr("WESTERN DIGITAL WD10EZEX-00BN5A0 S/N: WCC4N1234567 1 TB")
        assertEquals("WD10EZEX-00BN5A0", o.model)
        assertEquals("WCC4N1234567", o.serial)
        assertEquals("Western Digital", o.brand)
        assertEquals("1 TB", o.capacity)
    }

    @Test fun capacityFromModelCodes() {
        assertEquals(1000.0, LabelParser.capacityFromModel("WD10EZEX")!!, 0.0)
        assertEquals(4000.0, LabelParser.capacityFromModel("WD40EFRX")!!, 0.0)
        assertEquals(500.0, LabelParser.capacityFromModel("WD5000AAKX")!!, 0.0)
        assertEquals(1000.0, LabelParser.capacityFromModel("WD1003FZEX")!!, 0.0)
        assertEquals(500.0, LabelParser.capacityFromModel("ST3500418AS")!!, 0.0)
        assertEquals(1000.0, LabelParser.capacityFromModel("DT01ACA100")!!, 0.0)
        assertEquals(480.0, LabelParser.capacityFromModel("SA400S37/480G")!!, 0.0)
    }

    // ---------- موتور تصمیم ----------

    @Test fun greenAfterTwoAgreeingFrames() {
        val d = SerialDecider()
        val codes = listOf("WXI2A345", "123456789012")
        assertEquals(Level.PENDING, d.onFrame(0, ocr("WX12A345"), codes).level)
        val v = d.onFrame(600, ocr("WX12A345"), codes)
        assertEquals(Level.GREEN, v.level)
        assertEquals("WXI2A345", v.serial)        // مقدار نهایی از بارکد است، نه OCR
        assertTrue(v.confirmed)
    }

    @Test fun greenResultIsLocked() {
        val d = SerialDecider()
        val codes = listOf("WXI2A345")
        d.onFrame(0, ocr("WX12A345"), codes)
        d.onFrame(600, ocr("WX12A345"), codes)
        val later = d.onFrame(5000, ocr(null), emptyList())
        assertEquals(Level.GREEN, later.level)
    }

    @Test fun yellowWhenOnlyOcrIsStable() {
        val d = SerialDecider()
        var v = Verdict()
        for (t in listOf(0L, 1000L, 2000L, 3000L)) v = d.onFrame(t, ocr("WX12A345"), emptyList())
        assertEquals(Level.YELLOW, v.level)
        assertEquals("OCR", v.source)
        assertEquals("WX12A345", v.serial)
    }

    @Test fun yellowWhenModelIsMissing() {
        val d = SerialDecider()
        val codes = listOf("WXI2A345")
        d.onFrame(0, ocr("WX12A345", model = null), codes)
        val v = d.onFrame(600, ocr("WX12A345", model = null), codes)
        assertEquals(Level.YELLOW, v.level)
    }

    @Test fun redWhenTwoBarcodesAreAmbiguous() {
        val d = SerialDecider()
        val v = d.onFrame(0, ocr("WX12A345"), listOf("WX12A346", "WX12A347"))
        assertEquals(Level.RED, v.level)
    }

    @Test fun redWhenTooManyBarcodes() {
        val d = SerialDecider()
        val many = (1..7).map { "AB12CD3$it" }
        assertEquals(Level.RED, d.onFrame(0, ocr("WX12A345"), many).level)
    }

    @Test fun orangeWhenOnlyBarcodeMatchesBrandFormat() {
        val d = SerialDecider()
        val o = ocr(null, model = "ST1000DM010", brand = "Seagate")
        var v = Verdict()
        for (t in listOf(0L, 1500L, 3000L)) v = d.onFrame(t, o, listOf("Z1D3ABCD"))
        assertEquals(Level.ORANGE, v.level)
        assertEquals("Z1D3ABCD", v.serial)
    }

    @Test fun redAfterTimeoutWithNothing() {
        val d = SerialDecider()
        d.onFrame(0, ocr(null), listOf("12345678"))
        val v = d.onFrame(11000, ocr(null), listOf("12345678"))
        assertEquals(Level.RED, v.level)
    }

    @Test fun blueWhenSerialAlreadySaved() {
        val d = SerialDecider { s -> Sim.canon(s) == Sim.canon("WX12A345") }
        val codes = listOf("WXI2A345")
        d.onFrame(0, ocr("WX12A345"), codes)
        val v = d.onFrame(600, ocr("WX12A345"), codes)
        assertEquals(Level.BLUE, v.level)
    }

    @Test fun newDriveIsDetectedAfterLock() {
        val d = SerialDecider()
        val codes = listOf("WXI2A345")
        d.onFrame(0, ocr("WX12A345"), codes)
        d.onFrame(600, ocr("WX12A345"), codes)
        assertFalse(d.newDriveDetected)
        for (t in listOf(2000L, 2600L, 3200L)) d.onFrame(t, ocr(null), listOf("QQ77R2233"))
        assertTrue(d.newDriveDetected)
    }

    @Test fun modelBarcodeIsNotCandidate() {
        val d = SerialDecider()
        val v = d.onFrame(0, ocr("WX12A345"), listOf("WD10EZEX-00BN5A0"))
        assertTrue(v.level != Level.GREEN)
    }
}
